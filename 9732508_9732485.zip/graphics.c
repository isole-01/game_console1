//
// Created by Tr on 7/2/2019.
//
extern char solidblock;
extern char deathblock;
extern char moveblock;
extern char wall;
extern char up;
extern char right;
extern char down;
extern char left;
extern char character;
extern int game_time;
extern char target;
extern char object;
extern char opp[];
extern char put[];
extern int put_limit;
extern char rpoint_char;
extern int rpoint_score;
extern int rpoint_num;
extern int attack;
extern int raindb;
extern int map_len;
extern int map_wid;
extern char game_exit;


extern char **map;
#include "game_console.h"



